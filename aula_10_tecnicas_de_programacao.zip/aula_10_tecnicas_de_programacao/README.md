# TP2 Aula 10 — Adapter e Facade

## Atividade
Aula 10 — Padrões Estruturais I: Adapter e Facade.

## Objetivo
Este projeto é uma estrutura de estudo baseada no enunciado da atividade.
O código-fonte original fornecido pelo professor não estava disponível no arquivo enviado,
portanto as implementações abaixo são apenas pontos de partida e NÃO constituem a solução final.

## O que precisa ser desenvolvido

### Adapter
- Criar `FonteDeAlunos`.
- Criar `AdaptadorSecretariaLegado`.
- Manter `SecretariaLegadoWS` sem alterações.
- Concentrar a conversão do formato legado em um único lugar.
- Aplicar também a regra da letra minúscula.

### Facade
- Criar `FachadaMatricula`.
- Retirar da `TelaMatricula` a sequência de chamadas dos colaboradores.
- A tela deve ficar responsável somente pela chamada da fachada e pelo tratamento de erro.

## Evidências exigidas
1. Identificar os dois trechos originais de conversão e explicar a divergência.
2. Mostrar a interface e o Adapter.
3. Mostrar que `ImportadorAlunos` e `RelatorioSituacao` dependem da abstração.
4. Mostrar a `FachadaMatricula` e a simplificação da tela.
5. Explicar por que Adapter e Facade resolvem os problemas encontrados.

## Observação
Antes de usar este projeto como entrega, compare com o código original fornecido pelo professor
e complete as partes necessárias de acordo com o comportamento original.
