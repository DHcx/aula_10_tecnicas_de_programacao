public class FachadaMatricula {

    // TODO:
    // Receber os colaboradores necessários e mover para esta classe
    // a ordem correta de execução que atualmente está na TelaMatricula.

    public void matricular() {
        // TODO: implementar com base no código original.
        throw new UnsupportedOperationException("Implementar com os colaboradores originais");
    }
}
