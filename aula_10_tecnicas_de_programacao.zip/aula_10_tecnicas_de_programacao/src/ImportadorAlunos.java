public class ImportadorAlunos {

    private final FonteDeAlunos fonteDeAlunos;

    public ImportadorAlunos(FonteDeAlunos fonteDeAlunos) {
        this.fonteDeAlunos = fonteDeAlunos;
    }

    public void importar() {
        // TODO: preservar o comportamento do código original.
        fonteDeAlunos.obterAlunos();
    }
}
