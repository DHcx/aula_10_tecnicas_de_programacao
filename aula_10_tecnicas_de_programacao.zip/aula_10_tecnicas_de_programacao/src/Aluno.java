public class Aluno {
    private String matricula;
    private String nome;
    private String situacao;

    public Aluno(String matricula, String nome, String situacao) {
        this.matricula = matricula;
        this.nome = nome;
        this.situacao = situacao;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public String getSituacao() {
        return situacao;
    }
}
