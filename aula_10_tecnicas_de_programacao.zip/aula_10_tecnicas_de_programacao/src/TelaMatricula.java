public class TelaMatricula {

    private final FachadaMatricula fachadaMatricula;

    public TelaMatricula(FachadaMatricula fachadaMatricula) {
        this.fachadaMatricula = fachadaMatricula;
    }

    public void executarMatricula() {
        try {
            fachadaMatricula.matricular();
        } catch (Exception e) {
            // A tela deve tratar o erro, sem conhecer a ordem dos colaboradores.
            System.out.println("Erro na matrícula: " + e.getMessage());
        }
    }
}
