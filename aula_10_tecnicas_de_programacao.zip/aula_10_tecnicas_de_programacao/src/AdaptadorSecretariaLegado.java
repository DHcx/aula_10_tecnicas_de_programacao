import java.util.List;

public class AdaptadorSecretariaLegado implements FonteDeAlunos {

    private final SecretariaLegadoWS secretariaLegado;

    public AdaptadorSecretariaLegado(SecretariaLegadoWS secretariaLegado) {
        this.secretariaLegado = secretariaLegado;
    }

    @Override
    public List<Aluno> obterAlunos() {
        // TODO:
        // Converter aqui, em um único lugar, o formato retornado
        // pelo serviço legado para o formato esperado pelo sistema.
        //
        // A regra da letra minúscula deve ser tratada aqui.
        throw new UnsupportedOperationException("Implementar com base no código original");
    }
}
