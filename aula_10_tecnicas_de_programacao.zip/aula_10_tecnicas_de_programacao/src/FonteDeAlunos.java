import java.util.List;

public interface FonteDeAlunos {
    List<Aluno> obterAlunos();
}
