public class SecretariaLegadoWS {

    // TODO:
    // Substituir pelo código EXATO fornecido pelo professor.
    // Esta classe não deve ser modificada na solução final.

    public String[][] consultarAlunos() {
        throw new UnsupportedOperationException(
            "Inserir o código original fornecido pelo professor"
        );
    }
}
