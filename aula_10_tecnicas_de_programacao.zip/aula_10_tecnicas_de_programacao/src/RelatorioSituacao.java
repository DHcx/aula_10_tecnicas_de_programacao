public class RelatorioSituacao {

    private final FonteDeAlunos fonteDeAlunos;

    public RelatorioSituacao(FonteDeAlunos fonteDeAlunos) {
        this.fonteDeAlunos = fonteDeAlunos;
    }

    public void gerar() {
        // TODO: preservar o comportamento do código original.
        fonteDeAlunos.obterAlunos();
    }
}
