public class Main {

    public static void main(String[] args) {
        System.out.println("Estrutura de estudo — Aula 10 Adapter e Facade.");
        System.out.println("Complete as implementações usando o código original da atividade.");
    }
}
